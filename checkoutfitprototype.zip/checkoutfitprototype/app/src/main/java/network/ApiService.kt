package com.example.checkoutfitprototype.network

import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.*

// ESTAS SON LAS ÚNICAS DATA CLASSES QUE DEBEN ESTAR AQUÍ O EN SUS PROPIOS ARCHIVOS
// (Asegúrate de que no estén duplicadas en otros lugares)

// Representa los datos de una prenda de ropa
data class ClothingItem(
    val id: Int,
    val userId: Int,
    val category: String,
    val imageUrl: String
)


interface ApiService {


    @POST("api/auth/register")
    suspend fun register(@Body body: RegisterRequest): Response<UserData>

    @POST("api/auth/login")
    suspend fun login(@Body body: LoginRequest): Response<LoginResponse>

    @Multipart
    @POST("upload_clothing.php")
    suspend fun uploadClothing(
        @Part("user_id") userId: RequestBody,
        @Part("category") category: RequestBody,
        @Part image: MultipartBody.Part
    ): Response<Unit>

    @GET("get_clothing.php")
    suspend fun getAllClothingByUser(@Query("user_id") userId: String): Response<List<ClothingItem>>

    @GET("get_all_clothing.php")
    suspend fun getAllClothing(): Response<List<ClothingItem>>
}
