package com.example.checkoutfitprototype.network

data class LoginResponse(
    val token: String,
    val user: UserData
)

data class UserData(
    val id: Int,
    val name: String?,
    val email: String
)
