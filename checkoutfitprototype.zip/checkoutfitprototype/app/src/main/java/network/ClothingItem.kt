package network


import com.google.gson.annotations.SerializedName


data class ClothingItem(

    @SerializedName("_id")
    val id: String,

    @SerializedName("user")
    val userId: String,

    @SerializedName("category")
    val category: String,

    @SerializedName("color")
    val color: String,

    @SerializedName("imageUrl")
    val imageUrl: String,

    // Tu backend debería enviar "tags" como un array de strings en el JSON.
    // Ejemplo: "tags": ["casual", "verano"]
    @SerializedName("tags")
    val tags: List<String>
)

