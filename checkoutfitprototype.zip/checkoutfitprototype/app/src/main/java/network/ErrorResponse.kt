package com.example.checkoutfitprototype.network

data class ErrorResponse(
    val success: Boolean,
    val message: String
)
