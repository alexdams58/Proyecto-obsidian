package com.example.checkoutfitprototype.network

import android.content.Context
import com.example.checkoutfitprototype.SessionManager
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class RetrofitInstance(private val context: Context) {


    private val BASE_URL = "https://backend-outfits.onrender.com/"


    val api: ApiService by lazy {


        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }


        val authInterceptor = AuthInterceptor(SessionManager(context))

        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .addInterceptor(authInterceptor)
            .build()


        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client) 
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}

