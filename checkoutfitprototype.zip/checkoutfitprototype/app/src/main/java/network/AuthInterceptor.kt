package com.example.checkoutfitprototype.network

import com.example.checkoutfitprototype.SessionManager
import okhttp3.Interceptor
import okhttp3.Response


class AuthInterceptor(private val sessionManager: SessionManager) : Interceptor {    override fun intercept(chain: Interceptor.Chain): Response {
    val requestBuilder = chain.request().newBuilder()
    val token = sessionManager.getToken()

    token?.let {
        requestBuilder.addHeader("Authorization", "Bearer $it")
    }

    return chain.proceed(requestBuilder.build())
}
}



