package network

data class AuthResponse(
    val msg: String,
    val usuario: Map<String, Any>? = null,
    val token: String? = null
)