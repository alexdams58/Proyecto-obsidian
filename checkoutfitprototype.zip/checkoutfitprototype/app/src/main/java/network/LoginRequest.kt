package com.example.checkoutfitprototype.network

data class LoginRequest(
    val email: String,
    val password: String
)