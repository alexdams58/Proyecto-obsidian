package com.example.checkoutfitprototype.network

data class AuthRequest(
    val email: String,
    val password: String
)
