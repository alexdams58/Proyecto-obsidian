package com.example.checkoutfitprototype

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import android.view.MenuItem
import android.content.Intent
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import com.example.checkoutfitprototype.network.ClothingItem
import com.bumptech.glide.Glide
import com.example.checkoutfitprototype.network.RetrofitInstance
import com.google.android.material.navigation.NavigationView


class OutfitGeneratorActivity : BaseActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var toggle: ActionBarDrawerToggle
    private lateinit var imagenTop: ImageView
    private lateinit var imagenBottom: ImageView
    private lateinit var imagenFootwear: ImageView
    private lateinit var botonGenerar: Button
    private var todaLaRopa: List<ClothingItem> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main6)


        drawerLayout = findViewById(R.id.drawer_layout)
        val navView: NavigationView = findViewById(R.id.nav_view)
        val toolbar: Toolbar = findViewById(R.id.toolbar)

        setSupportActionBar(toolbar)

        toggle = ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close)
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        navView.setNavigationItemSelectedListener(this)

        imagenTop = findViewById(R.id.imagen_top)
        imagenBottom = findViewById(R.id.imagen_bottom)
        imagenFootwear = findViewById(R.id.imagen_footwear)
        botonGenerar = findViewById(R.id.boton_generar)

        fetchTodaLaRopa()

        botonGenerar.setOnClickListener {
            if (todaLaRopa.isNotEmpty()) {
                generarYMostrarOutfit()
            } else {
                Toast.makeText(this, "Aún no se ha cargado la ropa, espera un momento.", Toast.LENGTH_SHORT).show()
            }
        }
    }


    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_change_style -> {
                val intent = Intent(this, StyleSelectionActivity::class.java)
                startActivity(intent)
            }
            R.id.nav_help -> {
                Toast.makeText(this, "Función de ayuda próximamente", Toast.LENGTH_SHORT).show()
            }
            R.id.nav_add_clothes -> { // <--- ¿TIENES ESTE ID Y ESTE CASO?
                val intent = Intent(this, UploadOutfitActivity::class.java)
                startActivity(intent)
            }
            R.id.nav_logout -> {

                sessionManager.clearAuthData()

                val intent = Intent(this, LoginActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            }
        }
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    private fun fetchTodaLaRopa() {
        lifecycleScope.launch {
            try {

                val response = api.api.getAllClothing()

                if (response.isSuccessful) {
                    todaLaRopa = response.body() ?: emptyList()
                    if (todaLaRopa.isEmpty()) {
                        Toast.makeText(this@OutfitGeneratorActivity, "No tienes ropa registrada.", Toast.LENGTH_LONG).show()
                    } else {

                        Toast.makeText(this@OutfitGeneratorActivity, "¡Ropa cargada! Lista para generar.", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    val errorMsg = "Error al cargar la ropa: ${response.code()}"
                    Toast.makeText(this@OutfitGeneratorActivity, errorMsg, Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@OutfitGeneratorActivity, "Error de conexión: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun generarYMostrarOutfit() {
        val tops = todaLaRopa.filter { it.category.equals("Top", ignoreCase = true) }
        val bottoms = todaLaRopa.filter { it.category.equals("Bottom", ignoreCase = true) }
        val footwear = todaLaRopa.filter { it.category.equals("Footwear", ignoreCase = true) }

        if (tops.isEmpty() || bottoms.isEmpty() || footwear.isEmpty()) {
            Toast.makeText(this, "Necesitas al menos una prenda de cada categoría para generar un outfit.", Toast.LENGTH_LONG).show()
            return
        }

        val topSeleccionado = tops.random()
        val bottomSeleccionado = bottoms.random()
        val footwearSeleccionado = footwear.random()

        Glide.with(this).load(topSeleccionado.imageUrl).into(imagenTop)
        Glide.with(this).load(bottomSeleccionado.imageUrl).into(imagenBottom)
        Glide.with(this).load(footwearSeleccionado.imageUrl).into(imagenFootwear)
    }
}