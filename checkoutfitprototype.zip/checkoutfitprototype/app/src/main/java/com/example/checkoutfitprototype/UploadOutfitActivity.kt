package com.example.checkoutfitprototype

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.checkoutfitprototype.network.RetrofitInstance
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import com.bumptech.glide.Glide
import java.io.FileOutputStream

class UploadOutfitActivity : BaseActivity() {

    private lateinit var imageViewTop: ImageView
    private lateinit var imageViewBottom: ImageView
    private lateinit var imageViewShoes: ImageView
    private lateinit var buttonFinish: Button

    private var topUri: Uri? = null
    private var bottomUri: Uri? = null
    private var shoesUri: Uri? = null

    private var currentImageView: ImageView? = null

     private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {

                Toast.makeText(this, "Permiso concedido. Ya puedes seleccionar tus prendas.", Toast.LENGTH_LONG).show()

            } else {

                Toast.makeText(
                    this,
                    "Permiso denegado. No puedes subir fotos sin aceptar el permiso.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }


    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data?.data != null) {
                val selectedUri = result.data?.data!!
                when (currentImageView?.id) {
                    R.id.imageViewTop -> {
                        topUri = selectedUri
                        Glide.with(this).load(topUri).into(imageViewTop)
                    }
                    R.id.imageViewBottom -> {
                        bottomUri = selectedUri
                        Glide.with(this).load(bottomUri).into(imageViewBottom)
                    }
                    R.id.imageViewShoes -> {
                        shoesUri = selectedUri
                        Glide.with(this).load(shoesUri).into(imageViewShoes)
                    }
                }
            } else {
                Toast.makeText(this, "Selección de imagen cancelada", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main4)




        imageViewTop = findViewById(R.id.imageViewTop)
        imageViewBottom = findViewById(R.id.imageViewBottom)
        imageViewShoes = findViewById(R.id.imageViewShoes)
        buttonFinish = findViewById(R.id.buttonFinish)

        comprobarYPedirPermisos()

        imageViewTop.setOnClickListener {
            currentImageView = it as ImageView
            comprobarYPedirPermisos()
        }

        imageViewBottom.setOnClickListener {
            currentImageView = it as ImageView
            comprobarYPedirPermisos()
        }

        imageViewShoes.setOnClickListener {
            currentImageView = it as ImageView
            comprobarYPedirPermisos()
        }

        buttonFinish.setOnClickListener {
            subirOutfitCompleto()
        }
    }
    private fun getRequiredPermission(): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_IMAGES
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
    }

    private fun comprobarYPedirPermisos() {
        when {
            ContextCompat.checkSelfPermission(this, getRequiredPermission()) == PackageManager.PERMISSION_GRANTED -> {

            }
            shouldShowRequestPermissionRationale(getRequiredPermission()) -> {

                requestPermissionLauncher.launch(getRequiredPermission())
            }
            else -> {

                requestPermissionLauncher.launch(getRequiredPermission())
            }
        }
    }


    private fun abrirGaleriaSiHayPermiso() {

        if (ContextCompat.checkSelfPermission(this, getRequiredPermission()) == PackageManager.PERMISSION_GRANTED) {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            pickImageLauncher.launch(intent)
        } else {
            Toast.makeText(this, "Necesitas aceptar el permiso de acceso a fotos primero.", Toast.LENGTH_SHORT).show()
            comprobarYPedirPermisos()
        }
    }

    private fun subirOutfitCompleto() {
        if (topUri == null || bottomUri == null || shoesUri == null) {
            Toast.makeText(this, "Debes seleccionar las 3 prendas para subir el outfit", Toast.LENGTH_LONG).show()
            return
        }

        lifecycleScope.launch {
            val topSubido = subirPrenda(topUri!!, "Top")
            val bottomSubido = subirPrenda(bottomUri!!, "Bottom")
            val shoesSubidos = subirPrenda(shoesUri!!, "Footwear")

            if (topSubido && bottomSubido && shoesSubidos) {
                Toast.makeText(this@UploadOutfitActivity, "¡Outfit subido con éxito!", Toast.LENGTH_LONG).show()
                finish()
            } else {

                Toast.makeText(this@UploadOutfitActivity, "Error al subir una o más prendas", Toast.LENGTH_LONG).show()
            }
        }
    }

    private suspend fun subirPrenda(uri: Uri, categoria: String): Boolean {
        val file = uriToFile(uri) ?: return false


        val currentUserId = sessionManager.getUserId()
        if (currentUserId == -1) {
            Toast.makeText(this, "Error de sesión. Por favor, inicia sesión de nuevo.", Toast.LENGTH_LONG).show()
            return false
        }

        val userIdRequestBody = currentUserId.toString().toRequestBody("text/plain".toMediaTypeOrNull())
        val categoriaRequestBody = categoria.toRequestBody("text/plain".toMediaTypeOrNull())
        val fileRequestBody = file.asRequestBody("image/jpeg".toMediaTypeOrNull())
        val imagePart = MultipartBody.Part.createFormData("image", file.name, fileRequestBody)

        return try {

            val response = api.api.uploadClothing(userIdRequestBody, categoriaRequestBody, imagePart)
            response.isSuccessful
        } catch (e: Exception) {
            e.printStackTrace()

            Toast.makeText(this, "Fallo en la subida: ${e.message}", Toast.LENGTH_SHORT).show()
            false
        }
    }

    private fun uriToFile(uri: Uri): File? {
        return try {
            val inputStream = contentResolver.openInputStream(uri)
            val tempFile = File.createTempFile("upload_", ".jpg", cacheDir)
            tempFile.deleteOnExit()
            val outputStream = FileOutputStream(tempFile)
            inputStream?.copyTo(outputStream)
            inputStream?.close()
            outputStream.close()
            tempFile
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}