package com.example.checkoutfitprototype

import com.example.checkoutfitprototype.network.RegisterRequest
import com.example.checkoutfitprototype.network.RetrofitInstance
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import android.view.View
import android.widget.ProgressBar



class Register_Activity : BaseActivity() {



    private val TAG = "RegisterActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)


        val nameEditText = findViewById<EditText>(R.id.editUsuarioRegister)
        val emailEditText = findViewById<EditText>(R.id.editEmailregister)
        val passwordEditText = findViewById<EditText>(R.id.editContraseñaRegister)
        val confirmPasswordEditText = findViewById<EditText>(R.id.confirmarpassword)
        val registerButton = findViewById<Button>(R.id.btnRegister)
        val goToLoginButton = findViewById<Button>(R.id.btnGoToLogin)
        val progressBar = findViewById<ProgressBar>(R.id.progressBarRegister)


        registerButton.setOnClickListener {
            val name = nameEditText.text.toString().trim()
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()
            val confirmPassword = confirmPasswordEditText.text.toString().trim()


            if (name.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (password != confirmPassword) {
                Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            if (password.length < 8) {
                Toast.makeText(this, "La contraseña debe tener al menos 8 caracteres", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            // --- LÓGICA DE REGISTRO ---
            val registerRequest = RegisterRequest(name = name, email = email, password = password)
            Log.d(TAG, "Iniciando petición de registro para: $email")

            lifecycleScope.launch {
                registerButton.visibility = View.INVISIBLE
                progressBar.visibility = View.VISIBLE

                try {
                    val response = api.api.register(registerRequest)
                    if (response.isSuccessful) {
                        Log.d(TAG, "Registro exitoso para $email")
                        Toast.makeText(this@Register_Activity, "Registro exitoso. Ahora inicia sesión.", Toast.LENGTH_LONG).show()
                        val intent = Intent(this@Register_Activity, LoginActivity::class.java)
                        startActivity(intent)
                        finish() // Cierra la actividad de registro
                    } else {
                        val errorBody = response.errorBody()?.string() ?: "Error desconocido"
                        val errorCode = response.code()
                        Log.e(TAG, "Error en el registro. Código: $errorCode, Mensaje: $errorBody")
                        Toast.makeText(this@Register_Activity, "Error ($errorCode): $errorBody", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Excepción durante el registro: ${e.message}", e)
                    Toast.makeText(this@Register_Activity, "Error de conexión: ${e.message}", Toast.LENGTH_LONG).show()
                } finally {
                    registerButton.visibility = View.VISIBLE
                    progressBar.visibility = View.GONE
                }
            }
        }


        goToLoginButton.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}