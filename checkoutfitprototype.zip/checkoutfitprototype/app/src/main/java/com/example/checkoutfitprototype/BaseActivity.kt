package com.example.checkoutfitprototype

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.checkoutfitprototype.network.RetrofitInstance


abstract class BaseActivity : AppCompatActivity() {


    lateinit var sessionManager: SessionManager


    val api: RetrofitInstance by lazy {
        RetrofitInstance(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        sessionManager = SessionManager(this)
    }
}
