package com.example.checkoutfitprototype

import android.content.Intent
import android.os.Bundle
import com.google.android.material.card.MaterialCardView

// 1. CAMBIADO: Hereda de BaseActivity para ser consistente con el resto de la app
class StyleSelectionActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        val cardHombre = findViewById<MaterialCardView>(R.id.card_hombre)
        val cardMujer = findViewById<MaterialCardView>(R.id.card_mujer)


        cardHombre.setOnClickListener {

            navigateToGeneratorScreen("Hombre")
        }


        cardMujer.setOnClickListener {
            navigateToGeneratorScreen("Mujer")
        }
    }


    private fun navigateToGeneratorScreen(style: String) {

        val intent = Intent(this, OutfitGeneratorActivity::class.java)


        startActivity(intent)
    }
}