package com.example.checkoutfitprototype

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.checkoutfitprototype.network.RetrofitInstance
import kotlinx.coroutines.launch
import android.widget.ProgressBar
import android.view.View
import com.example.checkoutfitprototype.network.LoginRequest

class LoginActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val emailEditText = findViewById<EditText>(R.id.editUsuario)
        val passwordEditText = findViewById<EditText>(R.id.editContrasena)
        val botonLogin = findViewById<Button>(R.id.Logintext)
        val botonRegistro = findViewById<Button>(R.id.registertext)
        val progressBar = findViewById<ProgressBar>(R.id.progressBarLogin)

        botonLogin.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Por favor, introduce email y contraseña", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val loginRequest = LoginRequest(email = email, password = password)

            lifecycleScope.launch {
                botonLogin.visibility = View.INVISIBLE
                progressBar.visibility = View.VISIBLE

                try {

                    val response = api.api.login(loginRequest)

                    if (response.isSuccessful && response.body() != null) {
                        val userId = response.body()!!.user.id
                        val token = response.body()!!.token

                        sessionManager.saveAuthData(userId, token)

                        Toast.makeText(this@LoginActivity, "Login exitoso", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this@LoginActivity, StyleSelectionActivity::class.java)
                        startActivity(intent)
                        finish()
                    } else {
                        Toast.makeText(this@LoginActivity, "Error: Email o contraseña incorrectos", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this@LoginActivity, "Error de conexión: ${e.message}", Toast.LENGTH_LONG).show()
                } finally {
                    botonLogin.visibility = View.VISIBLE
                    progressBar.visibility = View.GONE
                }
            }
        }


        botonRegistro.setOnClickListener {
            val intent = Intent(this, Register_Activity::class.java)
            startActivity(intent)
        }
    }
}