
package com.example.checkoutfitprototype

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)

    companion object {
        const val USER_ID = "user_id"
        const val USER_TOKEN = "user_token" // <-- NUEVA CLAVE PARA EL TOKEN
    }

    // --- FUNCIÓN ACTUALIZADA ---
    fun saveAuthData(userId: Int, token: String) {
        val editor = prefs.edit()
        editor.putInt(USER_ID, userId)
        editor.putString(USER_TOKEN, token) // <-- GUARDA EL TOKEN
        editor.apply()
    }

    // --- NUEVA FUNCIÓN PARA OBTENER EL TOKEN ---
    fun getToken(): String? {
        return prefs.getString(USER_TOKEN, null)
    }

    fun getUserId(): Int {
        return prefs.getInt(USER_ID, -1)
    }

    fun isLoggedIn(): Boolean {
        // Un usuario está logueado si tiene un token válido guardado.
        return getToken() != null
    }

    fun clearAuthData() {
        val editor = prefs.edit()
        editor.remove(USER_ID)
        editor.remove(USER_TOKEN)
        editor.apply()
    }
}

